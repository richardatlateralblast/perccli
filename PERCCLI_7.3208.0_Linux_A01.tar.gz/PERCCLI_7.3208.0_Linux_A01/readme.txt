Description:
===========
This is a PERCCLI readme file mentioning instructions to use:
	1. PERCCLI  on all the supported operating systems.
	2. PERCCLI's JSON Schema files.
	3. PERCCLI's logging feature.

Please read before you start using PERCCLI executable.

Privileges:
=========
	1. PERCCLI should be installed / executed with administrative / root / super user privileges.
	2. Installed/Execution location should have Read/Write/Execute permissions.

	
Windows:
========
Installation / Execution: 
	1. PERCCLI is a executable. Copy-Paste the executable from where you want to execute. 

Sign verification:
	command : signtool.exe verify /v /pa <PERCCLI executable name>

Notes:  
	1. signtool.exe is required to validate the PERCCLI's signature. 

Linux:
======
Installation / Execution :
	1. Unzip the PERCCLI  package.
	2. To install the PERCCLI  RPM, run the rpm -ivh <PERCCLI-x.xx-x.noarch.rpm> command.
	3. To upgrade the PERCCLI  RPM, run the rpm -Uvh <PERCCLI-x.xx-x.noarch.rpm> command.

PERCCLI  RPM Verification:
	1. Import the public key to RPM DB. Command : rpm --import <public-key.asc>
	2. Verify the RPM signature. Command : rpm -Kv <PERCCLI -rpm>
	3. Install the PERCCLI  RPM. If imported public key is for the RPM being installed, No warnings should be shown during installation.
	4. Please adhere to the steps in the above mentioned order only.

VMware:
======
Installation:
	1. The PERCCLI VIB Package can be installed using the following syntax : esxcli software vib install -v=<Filepath of the PERCCLI VIB>
	2. The installed VIB Package can be removed using the following syntax : esxcli software vib remove -n=<VIB Name of PERCCLI >
	3. All the installed VIB Packages can be listed using following command: esxcli software vib list
 
FreeBSD:
========
Installation / Execution:
	1. Extract the tar archive and execute the PERCCLI .

Usage policies / Privileges:
	1. PERCCLI application will not function if the user is trying to run it in CSH, the default shell in FreeBSD.
	2. Please ensure that the user has entered the bash shell by executing the command "bash".

EFI:
====
Installation / Execution:
	1. From the boot menu, choose EFI Shell.
	2. Goto the folder containing the PERCCLI EFI binaries.
	3. Execute PERCCLI binaries.

Ubuntu:
=======
Installation:	
	1. Debian package can be installed using following command syntax : sudo dpkg -i <.deb package>
	2. Installed debian package can be verified using following command syntax : dpkg -l | grep -i PERCCLI 
	
PERCCLI Debian Verification:
	1. Import the public key to GPG DB. Command Syntax : gpg --import <pubKey.asc>
	2. Verify the GPG signature. Command Syntax : gpg --verify <perccli_x.xx-x_all.deb.sig> <perccli_x.xx-x_all.deb>
	3. Install the PercCLI Debian Package. If imported public key is for the Debian Package being installed, No warnings should be shown during installation.
	4. Please adhere to the steps in the above mentioned order only.

JSON-Schema:
=============
Installation: 
	1. Create a folder under /home/JSON-SCHEMA-FILES.
	2. Unzip the JSON-SCHEMA-FILES.zip and copy all the schema files to /home/JSON-SCHEMA-FILES (In any of the operating systems).
	
Command to Schema mapping:
	1. Please refer to the Schema_mapping_list.xlsx for command to schema mapping.

Logging:
========
	1. While executing PERCCLI, Logging is enabled by default.
	2. To Turn-off the logging, Place the perccliconf.ini in the current directory and change the DEBUGLEVEL to 0.
	3. To change the log level, Place the perccliconf.ini in the current directory and change the DEBUGLEVEL to any desired log level.
	4. In case of application crash, Place the perccliconf.ini in the current directory to capture logs.



